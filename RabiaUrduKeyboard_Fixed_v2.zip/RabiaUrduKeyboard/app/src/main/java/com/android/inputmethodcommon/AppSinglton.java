package com.android.inputmethodcommon;

/* JADX INFO: loaded from: classes.dex */
public class AppSinglton {
    public static Boolean isLongPressed = false;
}
