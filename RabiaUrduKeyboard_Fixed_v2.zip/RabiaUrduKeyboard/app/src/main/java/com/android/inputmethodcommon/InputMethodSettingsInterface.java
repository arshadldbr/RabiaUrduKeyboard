package com.android.inputmethodcommon;

import android.graphics.drawable.Drawable;

/* JADX INFO: loaded from: classes.dex */
public interface InputMethodSettingsInterface {
    void setInputMethodSettingsCategoryTitle(int i);

    void setInputMethodSettingsCategoryTitle(CharSequence charSequence);

    void setSubtypeEnablerIcon(int i);

    void setSubtypeEnablerIcon(Drawable drawable);

    void setSubtypeEnablerTitle(int i);

    void setSubtypeEnablerTitle(CharSequence charSequence);
}
