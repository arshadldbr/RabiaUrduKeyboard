package com.example.android.softkeyboard;

import android.content.Intent;
import android.inputmethodservice.InputMethodService;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.net.Uri;
import android.text.method.MetaKeyKeyListener;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.CompletionInfo;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.view.inputmethod.InputMethodSubtype;
import com.android.inputmethodcommon.AppSinglton;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import rabia.urdu.keyboard.softkeyboard.R;

/* JADX INFO: loaded from: classes.dex */
public class SoftKeyboard extends InputMethodService implements KeyboardView.OnKeyboardActionListener {
    static final boolean DEBUG = false;
    static final boolean PROCESS_HARD_KEYS = true;
    private CommentsDataSource datasource;
    private MySQLiteHelper dbHelper;
    ArrayList<String> list;
    private CandidateView mCandidateView;
    private boolean mCapsLock;
    private boolean mCompletionOn;
    private CompletionInfo[] mCompletions;
    private LatinKeyboard mCurKeyboard;
    private InputMethodManager mInputMethodManager;
    private LatinKeyboardView mInputView;
    private int mLastDisplayWidth;
    private long mLastShiftTime;
    private long mMetaState;
    private boolean mPredictionOn;
    private LatinKeyboard mQwertyKeyboard;
    private LatinKeyboard mQwertyKeyboard2;
    private LatinKeyboard mQwertytUrKeyboard;
    private LatinKeyboard mSymbolsKeyboard;
    private LatinKeyboard mSymbolsKeyboardUr;
    private LatinKeyboard mSymbolsShiftedKeyboard;
    private LatinKeyboard mSymbolsShiftedKeyboardUr;
    private String mWordSeparators;
    private StringBuilder mComposing = new StringBuilder();
    private boolean isUrdu = true;
    int langNo = 1;
    Boolean isFirtTime = true;

    @Override // android.inputmethodservice.InputMethodService, android.app.Service
    public void onCreate() {
        super.onCreate();
        this.mInputMethodManager = (InputMethodManager) getSystemService("input_method");
        this.mWordSeparators = getResources().getString(R.string.word_separators);
    }

    @Override // android.inputmethodservice.InputMethodService
    public void onComputeInsets(InputMethodService.Insets outInsets) {
        super.onComputeInsets(outInsets);
        if (!isFullscreenMode()) {
            outInsets.contentTopInsets = outInsets.visibleTopInsets;
        }
    }

    @Override // android.inputmethodservice.InputMethodService
    public void onInitializeInterface() {
        if (this.mQwertyKeyboard != null) {
            int displayWidth = getMaxWidth();
            if (displayWidth != this.mLastDisplayWidth) {
                this.mLastDisplayWidth = displayWidth;
            } else {
                return;
            }
        }
        this.mQwertyKeyboard = new LatinKeyboard(this, R.xml.qwerty);
        this.mSymbolsKeyboard = new LatinKeyboard(this, R.xml.symbols);
        this.mSymbolsShiftedKeyboard = new LatinKeyboard(this, R.xml.symbols_shift);
        this.mQwertytUrKeyboard = new LatinKeyboard(this, R.xml.qwetry_urdu);
        this.mQwertyKeyboard2 = new LatinKeyboard(this, R.xml.qwetrysecond);
        this.mSymbolsKeyboardUr = new LatinKeyboard(this, R.xml.symbols_ur);
        this.mSymbolsShiftedKeyboardUr = new LatinKeyboard(this, R.xml.symbols_shift_ur);
    }

    @Override // android.inputmethodservice.InputMethodService
    public View onCreateInputView() {
        this.mInputView = (LatinKeyboardView) getLayoutInflater().inflate(R.layout.input, (ViewGroup) null);
        this.mInputView.setOnKeyboardActionListener(this);
        this.mInputView.setKeyboard(this.mQwertyKeyboard);
        this.isUrdu = DEBUG;
        return this.mInputView;
    }

    @Override // android.inputmethodservice.InputMethodService
    public View onCreateCandidatesView() {
        this.mCandidateView = new CandidateView(this);
        this.mCandidateView.setService(this);
        return this.mCandidateView;
    }

    @Override // android.inputmethodservice.InputMethodService
    public void onStartInput(EditorInfo attribute, boolean restarting) {
        super.onStartInput(attribute, restarting);
        this.langNo = ((Globals) getApplication()).getData();
        this.mComposing.setLength(0);
        updateCandidates();
        if (!restarting) {
            this.mMetaState = 0L;
        }
        this.mPredictionOn = DEBUG;
        this.mCompletionOn = DEBUG;
        this.mCompletions = null;
        switch (attribute.inputType & 15) {
            case 1:
                if (this.langNo == 1) {
                    this.mCurKeyboard = this.mQwertytUrKeyboard;
                } else {
                    this.mCurKeyboard = this.mQwertyKeyboard;
                }
                this.mPredictionOn = true;
                int variation = attribute.inputType & 4080;
                if (variation == 128 || variation == 144) {
                    System.out.println("it is password feild");
                    this.mPredictionOn = DEBUG;
                }
                if (variation == 32 || variation == 16 || variation == 176) {
                    this.mPredictionOn = DEBUG;
                }
                if ((attribute.inputType & 65536) != 0) {
                    this.mCompletionOn = isFullscreenMode();
                }
                updateShiftKeyState(attribute);
                break;
            case 2:
            case 4:
                this.mCurKeyboard = this.mSymbolsKeyboard;
                break;
            case 3:
                this.mCurKeyboard = this.mSymbolsKeyboard;
                break;
            default:
                if (this.langNo == 1) {
                    this.mCurKeyboard = this.mQwertytUrKeyboard;
                } else {
                    this.mCurKeyboard = this.mQwertyKeyboard;
                }
                updateShiftKeyState(attribute);
                break;
        }
    }

    @Override // android.inputmethodservice.InputMethodService
    public void onFinishInput() {
        super.onFinishInput();
        this.mComposing.setLength(0);
        updateCandidates();
        setCandidatesViewShown(DEBUG);
        if (this.langNo == 1) {
            this.mCurKeyboard = this.mQwertytUrKeyboard;
        } else {
            this.mCurKeyboard = this.mQwertyKeyboard;
        }
        if (this.mInputView != null) {
            this.mInputView.closing();
        }
    }

    @Override // android.inputmethodservice.InputMethodService
    public void onStartInputView(EditorInfo attribute, boolean restarting) {
        super.onStartInputView(attribute, restarting);
        this.mInputView.setKeyboard(this.mCurKeyboard);
        this.mInputView.closing();
        InputMethodSubtype subtype = this.mInputMethodManager.getCurrentInputMethodSubtype();
        String selectedSubType = subtype.getLocale().substring(0, 2).toLowerCase();
        System.out.println("subtype has been set and it is " + selectedSubType);
        if (this.isFirtTime.booleanValue()) {
            this.isFirtTime = Boolean.valueOf(DEBUG);
            if (selectedSubType.equalsIgnoreCase("fa") && this.langNo == 1) {
                System.out.println("URDU VIEW IS SHOWING  ");
                this.mInputView.setKeyboard(this.mQwertytUrKeyboard);
                ((Globals) getApplication()).setData(1);
                this.isUrdu = true;
            } else {
                System.out.println("ENGLISH VIEW IS SHOWIZNG  ");
                this.mInputView.setKeyboard(this.mQwertyKeyboard);
                ((Globals) getApplication()).setData(2);
                this.isUrdu = DEBUG;
            }
        } else if (this.langNo == 1) {
            System.out.println("URDU VIEW IS SHOWING  ");
            this.mInputView.setKeyboard(this.mQwertytUrKeyboard);
            ((Globals) getApplication()).setData(1);
            this.isUrdu = true;
        } else {
            System.out.println("ENGLISH VIEW IS SHOWIZNG  ");
            this.mInputView.setKeyboard(this.mQwertyKeyboard);
            ((Globals) getApplication()).setData(2);
            this.isUrdu = DEBUG;
        }
        this.mInputView.setSubtypeOnSpaceKey(subtype);
    }

    @Override // android.inputmethodservice.InputMethodService
    public void onCurrentInputMethodSubtypeChanged(InputMethodSubtype subtype) {
    }

    @Override // android.inputmethodservice.InputMethodService
    public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd, int candidatesStart, int candidatesEnd) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd);
        if (this.mComposing.length() > 0) {
            if (newSelStart != candidatesEnd || newSelEnd != candidatesEnd) {
                this.mComposing.setLength(0);
                updateCandidates();
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) {
                    ic.finishComposingText();
                }
            }
        }
    }

    @Override // android.inputmethodservice.InputMethodService
    public void onDisplayCompletions(CompletionInfo[] completions) {
        if (this.mCompletionOn) {
            this.mCompletions = completions;
            if (completions == null) {
                setSuggestions(null, DEBUG, DEBUG);
                return;
            }
            List<String> stringList = new ArrayList<>();
            for (CompletionInfo ci : completions) {
                if (ci != null) {
                    stringList.add(ci.getText().toString());
                }
            }
            setSuggestions(stringList, true, true);
        }
    }

    private boolean translateKeyDown(int keyCode, KeyEvent event) {
        this.mMetaState = MetaKeyKeyListener.handleKeyDown(this.mMetaState, keyCode, event);
        int c = event.getUnicodeChar(MetaKeyKeyListener.getMetaState(this.mMetaState));
        this.mMetaState = MetaKeyKeyListener.adjustMetaAfterKeypress(this.mMetaState);
        InputConnection ic = getCurrentInputConnection();
        if (c == 0 || ic == null) {
            return DEBUG;
        }
        if ((Integer.MIN_VALUE & c) != 0) {
            c &= Integer.MAX_VALUE;
        }
        if (this.mComposing.length() > 0) {
            char accent = this.mComposing.charAt(this.mComposing.length() - 1);
            int composed = KeyEvent.getDeadChar(accent, c);
            if (composed != 0) {
                c = composed;
                this.mComposing.setLength(this.mComposing.length() - 1);
            }
        }
        onKey(c, null);
        return true;
    }

    @Override // android.inputmethodservice.InputMethodService, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        InputConnection ic;
        switch (keyCode) {
            case 4:
                if (event.getRepeatCount() == 0 && this.mInputView != null && this.mInputView.handleBack()) {
                    return true;
                }
                break;
            case 66:
                return DEBUG;
            case 67:
                if (this.mComposing.length() > 0) {
                    onKey(-5, null);
                    return true;
                }
                break;
            default:
                if (AppSinglton.isLongPressed.booleanValue()) {
                    AppSinglton.isLongPressed = Boolean.valueOf(DEBUG);
                    System.out.print("long presseddddd");
                    Intent i = new Intent("android.settings.LOCALE_SETTINGS");
                    getApplicationContext().startActivity(i);
                    return true;
                }
                if (keyCode == 62 && (event.getMetaState() & 2) != 0 && (ic = getCurrentInputConnection()) != null) {
                    ic.clearMetaKeyStates(2);
                    keyDownUp(29);
                    keyDownUp(42);
                    keyDownUp(32);
                    keyDownUp(46);
                    keyDownUp(43);
                    keyDownUp(37);
                    keyDownUp(32);
                    return true;
                }
                if (this.mPredictionOn && translateKeyDown(keyCode, event)) {
                    return true;
                }
                break;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override // android.inputmethodservice.InputMethodService, android.view.KeyEvent.Callback
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (this.mPredictionOn) {
            this.mMetaState = MetaKeyKeyListener.handleKeyUp(this.mMetaState, keyCode, event);
        }
        return super.onKeyUp(keyCode, event);
    }

    private void commitTyped(InputConnection inputConnection) {
        if (this.mComposing.length() > 0) {
            System.out.println("mcomposing " + ((Object) this.mComposing) + "lenth " + this.mComposing.length());
            inputConnection.commitText(this.mComposing, 1);
            this.mComposing.setLength(0);
            updateCandidates();
        }
    }

    private void updateShiftKeyState(EditorInfo attr) {
        if (attr != null && this.mInputView != null && this.mQwertyKeyboard == this.mInputView.getKeyboard()) {
            int caps = 0;
            EditorInfo ei = getCurrentInputEditorInfo();
            if (ei != null && ei.inputType != 0) {
                caps = getCurrentInputConnection().getCursorCapsMode(attr.inputType);
            }
            System.out.println("UPDATE SHIFT KEY STATE");
            this.mInputView.setShifted(this.mCapsLock || caps != 0);
            if (this.isUrdu) {
                System.out.println("handlebackspace isurdu");
                this.mQwertyKeyboard.setShifted(DEBUG);
            }
        }
    }

    private boolean isAlphabet(int code) {
        if (Character.isLetter(code)) {
            return true;
        }
        return DEBUG;
    }

    private void keyDownUp(int keyEventCode) {
        getCurrentInputConnection().sendKeyEvent(new KeyEvent(0, keyEventCode));
        getCurrentInputConnection().sendKeyEvent(new KeyEvent(1, keyEventCode));
    }

    private void sendKey(int keyCode) {
        switch (keyCode) {
            case 10:
                keyDownUp(66);
                break;
            default:
                if (keyCode >= 48 && keyCode <= 57) {
                    keyDownUp((keyCode - 48) + 7);
                } else {
                    getCurrentInputConnection().commitText(String.valueOf((char) keyCode), 1);
                }
                break;
        }
    }

    @Override // android.inputmethodservice.KeyboardView.OnKeyboardActionListener
    public void onKey(int primaryCode, int[] keyCodes) {
        Keyboard current;
        Keyboard current2;
        if (AppSinglton.isLongPressed.booleanValue()) {
            AppSinglton.isLongPressed = Boolean.valueOf(DEBUG);
            System.out.print("long presseddddd");
            Intent intent = new Intent("android.settings.INPUT_METHOD_SETTINGS");
            intent.addFlags(268435456);
            getApplicationContext().startActivity(intent);
            return;
        }
        if (this.isUrdu) {
            System.out.println("primary code =============" + primaryCode + "  and in urdu");
            if (isWordSeparator(primaryCode) || primaryCode == 39 || primaryCode == 34 || primaryCode == 8219) {
                System.out.println("it is word separator" + primaryCode);
                if (this.mComposing.length() > 0) {
                    commitTyped(getCurrentInputConnection());
                }
                sendKey(primaryCode);
                updateShiftKeyState(getCurrentInputEditorInfo());
                return;
            }
            if (primaryCode == -5) {
                handleBackspace();
                return;
            }
            if (primaryCode == -1) {
                handleShiftUrdu();
                return;
            }
            if (primaryCode == -3) {
                handleClose();
                return;
            }
            if (primaryCode != -100) {
                if (primaryCode == -2 && this.mInputView != null) {
                    Keyboard current3 = this.mInputView.getKeyboard();
                    if (current3 == this.mSymbolsKeyboardUr || current3 == this.mSymbolsShiftedKeyboardUr) {
                        current2 = this.mQwertytUrKeyboard;
                    } else {
                        current2 = this.mSymbolsKeyboardUr;
                    }
                    this.mInputView.setKeyboard(current2);
                    if (current2 == this.mSymbolsKeyboardUr) {
                        current2.setShifted(DEBUG);
                        return;
                    }
                    return;
                }
                if (primaryCode == -10) {
                    this.isUrdu = DEBUG;
                    ((Globals) getApplication()).setData(2);
                    this.mInputView.setKeyboard(this.mQwertyKeyboard);
                    return;
                }
                handleCharacter(primaryCode, keyCodes);
                return;
            }
            return;
        }
        System.out.println("primary code =============" + primaryCode + "  and in inglish");
        if (isWordSeparator(primaryCode) || primaryCode == 39 || primaryCode == 34 || primaryCode == 8219) {
            if (this.mComposing.length() > 0) {
                commitTyped(getCurrentInputConnection());
            }
            sendKey(primaryCode);
            updateShiftKeyState(getCurrentInputEditorInfo());
            return;
        }
        if (primaryCode == -5) {
            handleBackspace();
            return;
        }
        if (primaryCode == -1) {
            handleShift();
            return;
        }
        if (primaryCode == -3) {
            handleClose();
            return;
        }
        if (primaryCode != -100) {
            if (primaryCode == -2 && this.mInputView != null) {
                System.out.println("english symbolic");
                Keyboard current4 = this.mInputView.getKeyboard();
                if (current4 == this.mSymbolsKeyboard || current4 == this.mSymbolsShiftedKeyboard) {
                    current = this.mQwertyKeyboard;
                } else {
                    current = this.mSymbolsKeyboard;
                }
                this.mInputView.setKeyboard(current);
                if (current == this.mSymbolsKeyboard) {
                    current.setShifted(DEBUG);
                    return;
                }
                return;
            }
            if (primaryCode == -10) {
                this.isUrdu = true;
                ((Globals) getApplication()).setData(1);
                this.mInputView.setKeyboard(this.mQwertytUrKeyboard);
                this.mInputView.setShifted(DEBUG);
                return;
            }
            handleCharacter(primaryCode, keyCodes);
        }
    }

    @Override // android.inputmethodservice.KeyboardView.OnKeyboardActionListener
    public void onText(CharSequence text) {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) {
            ic.beginBatchEdit();
            if (this.mComposing.length() > 0) {
                commitTyped(ic);
            }
            ic.commitText(text, 0);
            ic.endBatchEdit();
            updateShiftKeyState(getCurrentInputEditorInfo());
        }
    }

    private void updateCandidates() {
        System.out.println("delete 4");
        if (!this.mCompletionOn) {
            if (this.mComposing.length() > 0) {
                this.datasource = new CommentsDataSource(this);
                this.datasource.open();
                List<Comment> values = this.datasource.getAllComments();
                this.list = new ArrayList<>();
                this.list.add(this.mComposing.toString());
                for (Comment c : values) {
                    if (c.getComment().startsWith(this.mComposing.toString())) {
                        this.list.add(c.getComment());
                    }
                }
                if (this.list.size() > 2) {
                    StringLengthListSort ss = new StringLengthListSort();
                    Collections.sort(this.list, ss);
                }
                setSuggestions(this.list, true, true);
                this.datasource.close();
                return;
            }
            System.out.println("UPDATECANDIDATES ELSE CONDITION");
            setSuggestions(null, DEBUG, DEBUG);
        }
    }

    public void setSuggestions(List<String> suggestions, boolean completions, boolean typedWordValid) {
        if (suggestions != null && suggestions.size() > 0) {
            System.out.println("SET SUGGESTION IN SOFTKEYBOARD " + suggestions.get(0));
            setCandidatesViewShown(true);
        } else if (isExtractViewShown()) {
            setCandidatesViewShown(true);
        }
        if (this.mCandidateView != null) {
            this.mCandidateView.setSuggestions(suggestions, completions, typedWordValid);
        }
    }

    private void handleBackspace() {
        int length = this.mComposing.length();
        if (length >= 1) {
            this.mComposing.delete(length - 1, length);
            getCurrentInputConnection().setComposingText(this.mComposing, 1);
            updateCandidates();
        } else if (length > 0) {
            this.mComposing.setLength(0);
            getCurrentInputConnection().commitText("", 0);
            updateCandidates();
        } else {
            System.out.println("delete button" + this.mComposing.length());
            keyDownUp(67);
        }
        updateShiftKeyState(getCurrentInputEditorInfo());
    }

    private void handleShiftUrdu() {
        System.out.println("current keyboard issssss" + this.mInputView);
        if (this.mInputView != null) {
            Keyboard currentKeyboard = this.mInputView.getKeyboard();
            System.out.println("current keyboard issssss" + currentKeyboard);
            if (this.mQwertytUrKeyboard == currentKeyboard) {
                this.mQwertytUrKeyboard.setShifted(true);
                this.mInputView.setKeyboard(this.mQwertyKeyboard2);
                this.mQwertyKeyboard2.setShifted(true);
                return;
            }
            if (currentKeyboard == this.mQwertyKeyboard2) {
                this.mQwertyKeyboard2.setShifted(DEBUG);
                this.mInputView.setKeyboard(this.mQwertytUrKeyboard);
                this.mQwertytUrKeyboard.setShifted(DEBUG);
            } else if (currentKeyboard == this.mSymbolsKeyboardUr) {
                this.mSymbolsKeyboardUr.setShifted(true);
                this.mInputView.setKeyboard(this.mSymbolsShiftedKeyboardUr);
                this.mSymbolsShiftedKeyboardUr.setShifted(true);
            } else if (currentKeyboard == this.mSymbolsShiftedKeyboardUr) {
                this.mSymbolsShiftedKeyboardUr.setShifted(DEBUG);
                this.mInputView.setKeyboard(this.mSymbolsKeyboardUr);
                this.mSymbolsKeyboardUr.setShifted(DEBUG);
            }
        }
    }

    private void handleShift() {
        boolean z = DEBUG;
        if (this.mInputView != null) {
            Keyboard currentKeyboard = this.mInputView.getKeyboard();
            if (this.mQwertyKeyboard == currentKeyboard) {
                checkToggleCapsLock();
                LatinKeyboardView latinKeyboardView = this.mInputView;
                if (this.mCapsLock || !this.mInputView.isShifted()) {
                    z = true;
                }
                latinKeyboardView.setShifted(z);
                System.out.println("CAPS LOCK ON<<" + this.mCapsLock + " and is shifted " + this.mInputView.isShifted());
                return;
            }
            if (currentKeyboard == this.mSymbolsKeyboard) {
                this.mSymbolsKeyboard.setShifted(true);
                this.mInputView.setKeyboard(this.mSymbolsShiftedKeyboard);
                this.mSymbolsShiftedKeyboard.setShifted(true);
            } else if (currentKeyboard == this.mSymbolsShiftedKeyboard) {
                this.mSymbolsShiftedKeyboard.setShifted(DEBUG);
                this.mInputView.setKeyboard(this.mSymbolsKeyboard);
                this.mSymbolsKeyboard.setShifted(DEBUG);
            }
        }
    }

    private void handleCharacter(int primaryCode, int[] keyCodes) {
        if (isInputViewShown() && this.mInputView.isShifted()) {
            primaryCode = Character.toUpperCase(primaryCode);
        }
        if (isAlphabet(primaryCode) && this.mPredictionOn) {
            System.out.println("handle character now update candadate called");
            this.mComposing.append((char) primaryCode);
            getCurrentInputConnection().setComposingText(this.mComposing, 1);
            updateShiftKeyState(getCurrentInputEditorInfo());
            updateCandidates();
            return;
        }
        System.out.println("ELSE....");
        if ((primaryCode >= 48 && primaryCode <= 58) || primaryCode == 1620 || ((primaryCode >= 1632 && primaryCode <= 1641) || primaryCode == 1648 || (primaryCode >= 1611 && primaryCode <= 1617))) {
            System.out.println("DIGIT ENTER");
            this.mComposing.append((char) primaryCode);
            getCurrentInputConnection().setComposingText(this.mComposing, 1);
            updateShiftKeyState(getCurrentInputEditorInfo());
            updateCandidates();
            return;
        }
        getCurrentInputConnection().commitText(String.valueOf((char) primaryCode), 1);
    }

    private void handleClose() {
        commitTyped(getCurrentInputConnection());
        requestHideSelf(0);
        this.mInputView.closing();
        Uri uri = Uri.parse("http://www.rabia.com.pk");
        Intent intent = new Intent("android.intent.action.VIEW", uri);
        intent.addFlags(268435456);
        startActivity(intent);
    }

    private void checkToggleCapsLock() {
        System.out.println("CHECKTOGGLECAPSLOCK");
        long now = System.currentTimeMillis();
        if (this.mLastShiftTime + 100 > now) {
            System.out.println("80000000");
            this.mCapsLock = this.mCapsLock ? DEBUG : true;
            this.mLastShiftTime = 0L;
            return;
        }
        this.mLastShiftTime = now;
    }

    private String getWordSeparators() {
        System.out.println("WORD IS from word separator  " + this.mWordSeparators);
        return this.mWordSeparators;
    }

    public boolean isWordSeparator(int code) {
        String separators = getWordSeparators();
        String test = String.valueOf((char) code);
        System.out.println("iswordseparator" + test);
        return separators.contains(String.valueOf((char) code));
    }

    public boolean isSpecialCharacter(int code) {
        return true;
    }

    public void pickDefaultCandidate() {
        pickSuggestionManually(0);
    }

    public void pickSuggestionManually(int index) {
        if (this.mCompletionOn && this.mCompletions != null && index >= 0 && index < this.mCompletions.length) {
            CompletionInfo ci = this.mCompletions[index];
            getCurrentInputConnection().commitCompletion(ci);
            if (this.mCandidateView != null) {
                this.mCandidateView.clear();
            }
            updateShiftKeyState(getCurrentInputEditorInfo());
            return;
        }
        if (this.mComposing.length() > 0) {
            System.out.println("PICKSUGGESTIONMANALLY");
            String wordSelected = this.list.get(index);
            this.mComposing.setLength(0);
            this.mComposing.append(wordSelected);
            this.mComposing.append(" ");
            this.dbHelper = new MySQLiteHelper(this);
            String storedUser = this.dbHelper.Exist(wordSelected);
            if (wordSelected.equals(storedUser)) {
                System.out.println("exixt");
            } else {
                this.datasource.open();
                this.datasource.createComment(wordSelected);
                this.datasource.close();
            }
            commitTyped(getCurrentInputConnection());
        }
    }

    @Override // android.inputmethodservice.KeyboardView.OnKeyboardActionListener
    public void swipeRight() {
        System.out.println("SWIPE RIGHT CALLED");
        if (this.mCompletionOn) {
            pickDefaultCandidate();
        }
    }

    @Override // android.inputmethodservice.KeyboardView.OnKeyboardActionListener
    public void swipeLeft() {
        System.out.println("SWIPE LEFT CALLED");
        handleBackspace();
    }

    @Override // android.inputmethodservice.KeyboardView.OnKeyboardActionListener
    public void swipeDown() {
        System.out.println("SWIPE DOWN CALLED");
        handleClose();
    }

    @Override // android.inputmethodservice.KeyboardView.OnKeyboardActionListener
    public void swipeUp() {
        System.out.println("SWIPE UP CALLED");
    }

    @Override // android.inputmethodservice.KeyboardView.OnKeyboardActionListener
    public void onPress(int primaryCode) {
    }

    @Override // android.inputmethodservice.KeyboardView.OnKeyboardActionListener
    public void onRelease(int primaryCode) {
    }
}
