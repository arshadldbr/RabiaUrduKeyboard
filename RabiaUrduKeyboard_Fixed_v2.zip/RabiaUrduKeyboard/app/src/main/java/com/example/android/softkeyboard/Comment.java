package com.example.android.softkeyboard;

/* JADX INFO: loaded from: classes.dex */
public class Comment {
    private String comment;
    private long id;

    public long getId() {
        return this.id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getComment() {
        return this.comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String toString() {
        return this.comment;
    }
}
