package com.example.android.softkeyboard;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.ImageView;
import rabia.urdu.keyboard.softkeyboard.R;

/* JADX INFO: loaded from: classes.dex */
public class StartActivity extends Activity {
    SharedPreferences appPreferences;
    ImageView hImageViewPic;
    ImageView oKBtn;
    ImageView secondImage;
    int[] images = {R.drawable.second, R.drawable.third1, R.drawable.finish};
    int count = 0;
    boolean isAppInstalled = false;

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        this.hImageViewPic = (ImageView) findViewById(R.id.first_screen_image);
        ShortcutIcon();
        this.oKBtn = (ImageView) findViewById(R.id.ok);
        this.oKBtn.setOnClickListener(new View.OnClickListener() { // from class: com.example.android.softkeyboard.StartActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View arg0) {
                Intent intent = new Intent(StartActivity.this, (Class<?>) ImePreferences.class);
                System.out.println("BEFORE count is " + StartActivity.this.count);
                if (StartActivity.this.count < 2) {
                    StartActivity.this.hImageViewPic.setImageResource(StartActivity.this.images[StartActivity.this.count]);
                }
                StartActivity.this.count++;
                if (StartActivity.this.count == 2 && StartActivity.this.count < 3) {
                    StartActivity.this.oKBtn.setImageResource(StartActivity.this.images[StartActivity.this.count]);
                }
                System.out.println(" count is " + StartActivity.this.count);
                if (StartActivity.this.count == 3) {
                    StartActivity.this.startActivity(intent);
                    System.exit(0);
                }
            }
        });
    }

    private void ShortcutIcon() {
        this.appPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        this.isAppInstalled = this.appPreferences.getBoolean("isAppInstalled", false);
        if (!this.isAppInstalled) {
            Intent HomeScreenShortCut = new Intent(getApplicationContext(), (Class<?>) StartActivity.class);
            HomeScreenShortCut.setAction("android.intent.action.MAIN");
            HomeScreenShortCut.addCategory("android.intent.category.LAUNCHER");
            HomeScreenShortCut.addFlags(268435456);
            HomeScreenShortCut.addFlags(67108864);
            Intent addIntent = new Intent();
            addIntent.putExtra("android.intent.extra.shortcut.INTENT", HomeScreenShortCut);
            addIntent.putExtra("android.intent.extra.shortcut.NAME", "Rabia UrduKeyBoard");
            addIntent.putExtra("android.intent.extra.shortcut.ICON_RESOURCE", Intent.ShortcutIconResource.fromContext(getApplicationContext(), R.drawable.logo6));
            addIntent.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
            addIntent.putExtra("duplicate", false);
            getApplicationContext().sendBroadcast(addIntent);
            SharedPreferences.Editor editor = this.appPreferences.edit();
            editor.putBoolean("isAppInstalled", true);
            editor.commit();
        }
    }
}
