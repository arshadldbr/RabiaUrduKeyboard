package com.example.android.softkeyboard;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class CommentsDataSource {
    private String[] allColumns = {MySQLiteHelper.COLUMN_ID, MySQLiteHelper.COLUMN_COMMENT};
    private SQLiteDatabase database;
    private MySQLiteHelper dbHelper;

    public CommentsDataSource(Context context) {
        this.dbHelper = new MySQLiteHelper(context);
    }

    public void open() throws SQLException {
        this.database = this.dbHelper.getWritableDatabase();
    }

    public void close() {
        this.dbHelper.close();
    }

    public Comment createComment(String comment) {
        ContentValues values = new ContentValues();
        values.put(MySQLiteHelper.COLUMN_COMMENT, comment);
        long insertId = this.database.insert(MySQLiteHelper.TABLE_COMMENTS, null, values);
        Cursor cursor = this.database.query(MySQLiteHelper.TABLE_COMMENTS, this.allColumns, "_id = " + insertId, null, null, null, null);
        cursor.moveToFirst();
        Comment newComment = cursorToComment(cursor);
        cursor.close();
        return newComment;
    }

    public void deleteComment(Comment comment) {
        long id = comment.getId();
        System.out.println("Comment deleted with id: " + id);
        this.database.delete(MySQLiteHelper.TABLE_COMMENTS, "_id = " + id, null);
    }

    public List<Comment> getAllComments() {
        List<Comment> comments = new ArrayList<>();
        Cursor cursor = this.database.query(MySQLiteHelper.TABLE_COMMENTS, this.allColumns, null, null, null, null, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Comment comment = cursorToComment(cursor);
            comments.add(comment);
            cursor.moveToNext();
        }
        cursor.close();
        return comments;
    }

    private Comment cursorToComment(Cursor cursor) {
        Comment comment = new Comment();
        comment.setId(cursor.getLong(0));
        comment.setComment(cursor.getString(1));
        return comment;
    }
}
