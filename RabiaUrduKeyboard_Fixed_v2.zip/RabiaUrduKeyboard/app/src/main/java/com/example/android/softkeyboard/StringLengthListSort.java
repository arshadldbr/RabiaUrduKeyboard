package com.example.android.softkeyboard;

import java.util.Comparator;

/* JADX INFO: loaded from: classes.dex */
class StringLengthListSort implements Comparator<String> {
    StringLengthListSort() {
    }

    @Override // java.util.Comparator
    public int compare(String s1, String s2) {
        return s1.length() - s2.length();
    }
}
