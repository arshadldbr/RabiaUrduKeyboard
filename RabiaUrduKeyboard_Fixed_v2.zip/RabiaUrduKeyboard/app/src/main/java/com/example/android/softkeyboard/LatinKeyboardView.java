package com.example.android.softkeyboard;

import android.content.Context;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.inputmethod.InputMethodSubtype;
import com.android.inputmethodcommon.AppSinglton;

public class LatinKeyboardView extends KeyboardView {

    static final int KEYCODE_OPTIONS = -100;

    // FIX 1: Debounce — minimum ms between two key presses to prevent phantom presses
    private static final long KEY_DEBOUNCE_MS = 30;
    private long mLastKeyPressTime = 0;

    // FIX 2: Track which pointer is our "active" pointer to ignore accidental multi-touch
    private int mActivePointerId = MotionEvent.INVALID_POINTER_ID;

    public LatinKeyboardView(Context context, AttributeSet attrs) {
        super(context, attrs);
        // FIX 3: Disable proximity correction which causes adjacent-key misfires
        setProximityCorrectionEnabled(false);
    }

    public LatinKeyboardView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        setProximityCorrectionEnabled(false);
    }

    /**
     * FIX: Override onTouchEvent to:
     *   1. Only track the FIRST pointer (ignore second finger touches)
     *   2. Debounce rapid successive taps
     *   3. Cancel secondary pointer interference
     */
    @Override
    public boolean onTouchEvent(MotionEvent me) {
        final int action = me.getActionMasked();

        switch (action) {
            case MotionEvent.ACTION_DOWN: {
                // First finger — record it as our active pointer
                mActivePointerId = me.getPointerId(0);
                break;
            }
            case MotionEvent.ACTION_POINTER_DOWN: {
                // FIX: A second finger was placed — ignore it completely
                // Synthesise an UP event for the current key so it doesn't get stuck,
                // then return true (consumed) so the parent never sees the second touch.
                int pointerIndex = me.getActionIndex();
                if (me.getPointerId(pointerIndex) != mActivePointerId) {
                    // Cancel the current key if needed, then bail out
                    MotionEvent cancelEvent = MotionEvent.obtain(me);
                    cancelEvent.setAction(MotionEvent.ACTION_CANCEL);
                    super.onTouchEvent(cancelEvent);
                    cancelEvent.recycle();
                    return true;
                }
                break;
            }
            case MotionEvent.ACTION_POINTER_UP: {
                // A non-primary finger lifted — ignore
                int pointerIndex = me.getActionIndex();
                if (me.getPointerId(pointerIndex) != mActivePointerId) {
                    return true;
                }
                break;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                mActivePointerId = MotionEvent.INVALID_POINTER_ID;
                break;
            }
        }

        // FIX: Debounce — if ACTION_DOWN fires too fast after the last press, skip it
        if (action == MotionEvent.ACTION_DOWN) {
            long now = System.currentTimeMillis();
            if (now - mLastKeyPressTime < KEY_DEBOUNCE_MS) {
                return true; // swallow the touch
            }
            mLastKeyPressTime = now;
        }

        return super.onTouchEvent(me);
    }

    @Override
    protected boolean onLongPress(Keyboard.Key key) {
        if (key.codes[0] == -3) {
            getOnKeyboardActionListener().onKey(KEYCODE_OPTIONS, null);
            return true;
        }
        if (key.codes[0] == 32) {
            AppSinglton.isLongPressed = true;
            return true;
        }
        return super.onLongPress(key);
    }

    void setSubtypeOnSpaceKey(InputMethodSubtype subtype) {
        // intentionally left empty
    }
}
