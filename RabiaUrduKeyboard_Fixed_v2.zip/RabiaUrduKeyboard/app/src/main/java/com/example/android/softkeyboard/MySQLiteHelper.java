package com.example.android.softkeyboard;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/* JADX INFO: loaded from: classes.dex */
public class MySQLiteHelper extends SQLiteOpenHelper {
    public static final String COLUMN_COMMENT = "comment";
    public static final String COLUMN_ID = "_id";
    private static final String DATABASE_CREATE = "create table comments(_id integer primary key autoincrement, comment text not null);";
    private static final String DATABASE_NAME = "commments.db";
    private static final int DATABASE_VERSION = 1;
    public static final String TABLE_COMMENTS = "comments";

    public MySQLiteHelper(Context context) {
        super(context, DATABASE_NAME, (SQLiteDatabase.CursorFactory) null, DATABASE_VERSION);
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onCreate(SQLiteDatabase database) {
        database.execSQL(DATABASE_CREATE);
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.w(MySQLiteHelper.class.getName(), "Upgrading database from version " + oldVersion + " to " + newVersion + ", which will destroy all old data");
        db.execSQL("DROP TABLE IF EXISTS comments");
        onCreate(db);
    }

    public void deleteWord(String word) {
        SQLiteDatabase db = getReadableDatabase();
        try {
            db.delete(TABLE_COMMENTS, "comment= '" + word + "'", null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String Exist(String user) {
        String username = "";
        SQLiteDatabase db = getReadableDatabase();
        try {
            Cursor c = db.query(TABLE_COMMENTS, null, "comment=?", new String[]{String.valueOf(user)}, null, null, null);
            if (c == null) {
                return "";
            }
            c.moveToFirst();
            username = c.getString(c.getColumnIndex(COLUMN_COMMENT));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return username;
    }
}
