package com.example.android.softkeyboard;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.drawable.Drawable;
import android.inputmethodservice.Keyboard;
import rabia.urdu.keyboard.softkeyboard.R;

/* JADX INFO: loaded from: classes.dex */
public class LatinKeyboard extends Keyboard {
    private Keyboard.Key mEnterKey;
    private Keyboard.Key mSpaceKey;

    public LatinKeyboard(Context context, int xmlLayoutResId) {
        super(context, xmlLayoutResId);
    }

    public LatinKeyboard(Context context, int layoutTemplateResId, CharSequence characters, int columns, int horizontalPadding) {
        super(context, layoutTemplateResId, characters, columns, horizontalPadding);
    }

    @Override // android.inputmethodservice.Keyboard
    protected Keyboard.Key createKeyFromXml(Resources res, Keyboard.Row parent, int x, int y, XmlResourceParser parser) {
        Keyboard.Key key = new LatinKey(res, parent, x, y, parser);
        if (key.codes[0] == 10) {
            this.mEnterKey = key;
        } else if (key.codes[0] == 32) {
            this.mSpaceKey = key;
        }
        return key;
    }

    void setImeOptions(Resources res, int options) {
        if (this.mEnterKey != null) {
            switch (1073742079 & options) {
                case 2:
                    this.mEnterKey.iconPreview = null;
                    this.mEnterKey.icon = null;
                    this.mEnterKey.label = res.getText(R.string.label_go_key);
                    break;
                case 3:
                    this.mEnterKey.icon = res.getDrawable(R.drawable.sym_keyboard_search);
                    this.mEnterKey.label = null;
                    break;
                case 4:
                    this.mEnterKey.iconPreview = null;
                    this.mEnterKey.icon = null;
                    this.mEnterKey.label = res.getText(R.string.label_send_key);
                    break;
                case 5:
                    this.mEnterKey.iconPreview = null;
                    this.mEnterKey.icon = null;
                    this.mEnterKey.label = res.getText(R.string.label_next_key);
                    break;
                default:
                    this.mEnterKey.icon = res.getDrawable(R.drawable.sym_keyboard_returnurdu);
                    this.mEnterKey.label = null;
                    break;
            }
        }
    }

    void setSpaceIcon(Drawable icon) {
        if (this.mSpaceKey != null) {
            this.mSpaceKey.icon = icon;
        }
    }

    static class LatinKey extends Keyboard.Key {
        public LatinKey(Resources res, Keyboard.Row parent, int x, int y, XmlResourceParser parser) {
            super(res, parent, x, y, parser);
        }

        @Override // android.inputmethodservice.Keyboard.Key
        public boolean isInside(int x, int y) {
            if (this.codes[0] == -3) {
                y -= 10;
            }
            return super.isInside(x, y);
        }
    }
}
