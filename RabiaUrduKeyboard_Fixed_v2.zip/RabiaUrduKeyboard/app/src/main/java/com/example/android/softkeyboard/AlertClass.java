package com.example.android.softkeyboard;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;

/* JADX INFO: loaded from: classes.dex */
public class AlertClass extends Activity {
    private MySQLiteHelper dbHelper;
    String word;

    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        this.word = intent.getStringExtra("delete");
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        Globals g = (Globals) getApplication();
        int data = g.getData();
        if (data == 1) {
            builder.setMessage(String.valueOf(this.word) + " \nØ¢Ù¾ Ú©ÛŒ Ù„ØºØª Ø³Û’ Ù…Ù¹ Ø¬Ø§Û“ Ú¯Ø§");
        } else {
            builder.setMessage(String.valueOf(this.word) + " \nwill romove from your learned words");
        }
        builder.setCancelable(false);
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() { // from class: com.example.android.softkeyboard.AlertClass.1
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int id) {
                AlertClass.this.del();
                AlertClass.this.finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() { // from class: com.example.android.softkeyboard.AlertClass.2
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
                AlertClass.this.finish();
            }
        });
        AlertDialog alert = builder.create();
        alert.show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void del() {
        this.dbHelper = new MySQLiteHelper(this);
        this.dbHelper.deleteWord(this.word);
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (Integer.parseInt(Build.VERSION.SDK) < 5 && keyCode == 4 && event.getRepeatCount() == 0) {
            Log.d("CDA", "onKeyDown Called");
            onBackPressed();
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        Log.d("CDA", "onBackPressed Called");
        Intent setIntent = new Intent("android.intent.action.MAIN");
        setIntent.addCategory("android.intent.category.HOME");
        setIntent.setFlags(268435456);
        startActivity(setIntent);
    }
}
