package com.example.android.softkeyboard;

import android.R;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class CandidateView extends View {
    private static final List<String> EMPTY_LIST = new ArrayList();
    private static final int MAX_SUGGESTIONS = 32;
    private static final int OUT_OF_BOUNDS = -1;
    private static final int SCROLL_PIXELS = 20;
    private static final int X_GAP = 10;
    Context context;
    final Handler handler;
    private Rect mBgPadding;
    private int mColorNormal;
    private int mColorOther;
    private int mColorRecommended;
    private GestureDetector mGestureDetector;
    Runnable mLongPressed;
    private Paint mPaint;
    private boolean mScrolled;
    private int mSelectedIndex;
    private Drawable mSelectionHighlight;
    private SoftKeyboard mService;
    private List<String> mSuggestions;
    private int mTargetScrollX;
    private int mTotalWidth;
    private int mTouchX;
    private boolean mTypedWordValid;
    private int mVerticalPadding;
    private int[] mWordWidth;
    private int[] mWordX;

    public CandidateView(Context context) {
        super(context);
        this.mTouchX = OUT_OF_BOUNDS;
        this.mWordWidth = new int[MAX_SUGGESTIONS];
        this.mWordX = new int[MAX_SUGGESTIONS];
        this.handler = new Handler();
        this.mLongPressed = new Runnable() { // from class: com.example.android.softkeyboard.CandidateView.1
            @Override // java.lang.Runnable
            public void run() {
                System.out.println(CandidateView.this.context);
                Intent intent = new Intent(CandidateView.this.context, (Class<?>) AlertClass.class).setFlags(268435456);
                intent.putExtra("delete", (String) CandidateView.this.mSuggestions.get(CandidateView.this.mSelectedIndex));
                CandidateView.this.context.startActivity(intent);
                Log.i("", "Long press!");
            }
        };
        this.context = context;
        this.mSelectionHighlight = context.getResources().getDrawable(R.drawable.list_selector_background);
        this.mSelectionHighlight.setState(new int[]{R.attr.state_enabled, R.attr.state_focused, R.attr.state_window_focused, R.attr.state_pressed});
        Resources r = context.getResources();
        setBackgroundColor(r.getColor(rabia.urdu.keyboard.softkeyboard.R.color.candidate_background));
        this.mColorNormal = r.getColor(rabia.urdu.keyboard.softkeyboard.R.color.candidate_normal);
        this.mColorRecommended = r.getColor(rabia.urdu.keyboard.softkeyboard.R.color.candidate_recommended);
        this.mColorOther = r.getColor(rabia.urdu.keyboard.softkeyboard.R.color.candidate_other);
        this.mVerticalPadding = r.getDimensionPixelSize(rabia.urdu.keyboard.softkeyboard.R.dimen.candidate_vertical_padding);
        this.mPaint = new Paint();
        this.mPaint.setColor(this.mColorNormal);
        this.mPaint.setAntiAlias(true);
        this.mPaint.setTextSize(r.getDimensionPixelSize(rabia.urdu.keyboard.softkeyboard.R.dimen.candidate_font_height));
        this.mPaint.setStrokeWidth(0.0f);
        this.mGestureDetector = new GestureDetector(new GestureDetector.SimpleOnGestureListener() { // from class: com.example.android.softkeyboard.CandidateView.2
            @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                CandidateView.this.mScrolled = true;
                int sx = (int) (CandidateView.this.getScrollX() + distanceX);
                if (sx < 0) {
                    sx = 0;
                }
                if (CandidateView.this.getWidth() + sx > CandidateView.this.mTotalWidth) {
                    sx = (int) (sx - distanceX);
                }
                CandidateView.this.mTargetScrollX = sx;
                CandidateView.this.scrollTo(sx, CandidateView.this.getScrollY());
                CandidateView.this.invalidate();
                return true;
            }
        });
        setHorizontalFadingEdgeEnabled(true);
        setWillNotDraw(false);
        setHorizontalScrollBarEnabled(true);
        setVerticalScrollBarEnabled(false);
    }

    public void setService(SoftKeyboard listener) {
        this.mService = listener;
    }

    @Override // android.view.View
    public int computeHorizontalScrollRange() {
        return this.mTotalWidth;
    }

    @Override // android.view.View
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int measuredWidth = resolveSize(50, widthMeasureSpec);
        Rect padding = new Rect();
        this.mSelectionHighlight.getPadding(padding);
        int desiredHeight = ((int) this.mPaint.getTextSize()) + this.mVerticalPadding + padding.top + padding.bottom;
        setMeasuredDimension(measuredWidth, resolveSize(desiredHeight, heightMeasureSpec));
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        if (canvas != null) {
            super.onDraw(canvas);
        }
        this.mTotalWidth = 0;
        if (this.mSuggestions != null) {
            if (this.mBgPadding == null) {
                this.mBgPadding = new Rect(0, 0, 0, 0);
                if (getBackground() != null) {
                    getBackground().getPadding(this.mBgPadding);
                }
            }
            int x = 0;
            int Count = this.mSuggestions.size();
            int height = getHeight();
            Rect bgPadding = this.mBgPadding;
            Paint paint = this.mPaint;
            int touchX = this.mTouchX;
            int scrollX = getScrollX();
            boolean scrolled = this.mScrolled;
            boolean typedWordValid = this.mTypedWordValid;
            int y = (int) (((height - this.mPaint.getTextSize()) / 2.0f) - this.mPaint.ascent());
            for (int i = 0; i < Count; i++) {
                String suggestion = this.mSuggestions.get(i);
                float textWidth = paint.measureText(suggestion);
                int wordWidth = ((getWidth() / 3) - (getWidth() / 6)) - (((int) textWidth) / 2);
                int cellWidth = getWidth() / 3;
                this.mWordX[i] = x;
                this.mWordWidth[i] = wordWidth;
                paint.setColor(this.mColorNormal);
                if (touchX + scrollX >= x && touchX + scrollX < x + cellWidth && !scrolled) {
                    if (canvas != null) {
                        canvas.translate(x, 0.0f);
                        this.mSelectionHighlight.setBounds(0, bgPadding.top, cellWidth, height);
                        this.mSelectionHighlight.draw(canvas);
                        canvas.translate(-x, 0.0f);
                    }
                    this.mSelectedIndex = i;
                }
                if (canvas != null) {
                    if ((i == 1 && !typedWordValid) || (i == 0 && typedWordValid)) {
                        paint.setFakeBoldText(true);
                        paint.setColor(this.mColorRecommended);
                    } else if (i != 0) {
                        paint.setColor(this.mColorOther);
                    }
                    canvas.drawText(suggestion, x + wordWidth, y, paint);
                    paint.setColor(this.mColorOther);
                    canvas.drawLine(0.5f + x + cellWidth, bgPadding.top, 0.5f + x + cellWidth, height + 1, paint);
                    paint.setFakeBoldText(false);
                }
                this.mPaint.setTextSize(36.0f);
                x += getWidth() / 3;
            }
            this.mTotalWidth = x;
            if (this.mTargetScrollX != getScrollX()) {
                scrollToTarget();
            }
        }
    }

    private void scrollToTarget() {
        int sx = getScrollX();
        if (this.mTargetScrollX > sx) {
            if (sx + SCROLL_PIXELS >= this.mTargetScrollX) {
                int sx2 = this.mTargetScrollX;
                requestLayout();
            }
        } else if (sx - 20 <= this.mTargetScrollX) {
            int sx3 = this.mTargetScrollX;
            requestLayout();
        }
        scrollTo(this.mTargetScrollX, getScrollY());
        invalidate();
    }

    public void setSuggestions(List<String> suggestions, boolean completions, boolean typedWordValid) {
        clear();
        if (suggestions != null) {
            this.mSuggestions = new ArrayList(suggestions);
        }
        this.mTypedWordValid = typedWordValid;
        scrollTo(0, 0);
        this.mTargetScrollX = 0;
        onDraw(null);
        invalidate();
        requestLayout();
    }

    public void clear() {
        this.mSuggestions = EMPTY_LIST;
        this.mTouchX = OUT_OF_BOUNDS;
        this.mSelectedIndex = OUT_OF_BOUNDS;
        invalidate();
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent me) {
        if (!this.mGestureDetector.onTouchEvent(me)) {
            int action = me.getAction();
            int x = (int) me.getX();
            int y = (int) me.getY();
            this.mTouchX = x;
            switch (action) {
                case 0:
                    this.handler.postDelayed(this.mLongPressed, 1000L);
                    this.mScrolled = false;
                    invalidate();
                    break;
                case 1:
                    this.handler.removeCallbacks(this.mLongPressed);
                    if (!this.mScrolled && this.mSelectedIndex >= 0) {
                        this.mService.pickSuggestionManually(this.mSelectedIndex);
                    }
                    this.mSelectedIndex = OUT_OF_BOUNDS;
                    removeHighlight();
                    requestLayout();
                    break;
                case 2:
                    if (y <= 0 && this.mSelectedIndex >= 0) {
                        this.mService.pickSuggestionManually(this.mSelectedIndex);
                        this.mSelectedIndex = OUT_OF_BOUNDS;
                    }
                    invalidate();
                    break;
            }
        }
        return true;
    }

    public void takeSuggestionAt(float x) {
        this.mTouchX = (int) x;
        onDraw(null);
        if (this.mSelectedIndex >= 0) {
            this.mService.pickSuggestionManually(this.mSelectedIndex);
        }
        invalidate();
    }

    private void removeHighlight() {
        this.mTouchX = OUT_OF_BOUNDS;
        invalidate();
    }
}
