package com.example.android.softkeyboard;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceActivity;
import com.android.inputmethodcommon.InputMethodSettingsFragment;
import rabia.urdu.keyboard.softkeyboard.R;

/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"NewApi"})
public class ImePreferences extends PreferenceActivity {
    @Override // android.app.Activity
    public Intent getIntent() {
        Intent modIntent = new Intent(super.getIntent());
        modIntent.putExtra(":android:show_fragment", Settings.class.getName());
        modIntent.putExtra(":android:no_headers", true);
        return modIntent;
    }

    @Override // android.preference.PreferenceActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.settings_name);
        System.out.println("APPLICATION IS INSTALLING...........");
    }

    public static class Settings extends InputMethodSettingsFragment {
        @Override // com.android.inputmethodcommon.InputMethodSettingsFragment, android.preference.PreferenceFragment, android.app.Fragment
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setInputMethodSettingsCategoryTitle(R.string.language_selection_title);
            setSubtypeEnablerTitle(R.string.select_language);
            addPreferencesFromResource(R.xml.ime_preferences);
        }
    }
}
