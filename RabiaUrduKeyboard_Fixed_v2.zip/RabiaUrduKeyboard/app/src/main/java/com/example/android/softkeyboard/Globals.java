package com.example.android.softkeyboard;

import android.app.Application;

/* JADX INFO: loaded from: classes.dex */
public class Globals extends Application {
    private int data = 1;

    public int getData() {
        return this.data;
    }

    public void setData(int d) {
        this.data = d;
    }
}
